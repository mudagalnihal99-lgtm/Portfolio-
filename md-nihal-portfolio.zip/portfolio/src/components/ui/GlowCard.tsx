import type { PropsWithChildren } from "react";
import { cn } from "@/lib/utils";

type GlowCardProps = PropsWithChildren<{
  className?: string;
  hover?: boolean;
}>;

export function GlowCard({ children, className, hover = true }: GlowCardProps) {
  return (
    <div
      className={cn(
        "group relative rounded-2xl border border-line bg-surface/60 p-6 backdrop-blur-sm",
        hover &&
          "transition-colors duration-300 hover:border-signal-cyan/30 hover:bg-surface-hover/70",
        className
      )}
    >
      {children}
    </div>
  );
}
