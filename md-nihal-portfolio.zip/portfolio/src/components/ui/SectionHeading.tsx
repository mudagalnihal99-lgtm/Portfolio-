import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

type SectionHeadingProps = {
  kicker: string;
  title: string;
  description?: string;
  align?: "left" | "center";
};

export function SectionHeading({ kicker, title, description, align = "left" }: SectionHeadingProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className={cn("mb-12 max-w-2xl", align === "center" && "mx-auto text-center")}
    >
      <div className={cn("mb-3 flex items-center gap-3", align === "center" && "justify-center")}>
        <span className="h-px w-8 bg-signal-gradient" />
        <span className="font-mono text-sm text-ash-500">{kicker}</span>
      </div>
      <h2 className="text-3xl font-semibold text-ash-100 sm:text-4xl">{title}</h2>
      {description && <p className="mt-4 text-base leading-relaxed text-ash-500">{description}</p>}
    </motion.div>
  );
}
