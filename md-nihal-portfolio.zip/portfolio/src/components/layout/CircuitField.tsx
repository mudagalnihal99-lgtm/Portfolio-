import { motion } from "framer-motion";

/**
 * A quiet, circuit-board inspired background: a faint grid plus a handful
 * of traced lines with a slow pulse. Purely decorative, aria-hidden, and
 * respects prefers-reduced-motion via Tailwind's motion-reduce variants.
 */
export function CircuitField() {
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
      <div
        className="absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            "linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)",
          backgroundSize: "56px 56px",
          maskImage: "radial-gradient(ellipse 70% 60% at 60% 30%, black 40%, transparent 100%)",
          WebkitMaskImage:
            "radial-gradient(ellipse 70% 60% at 60% 30%, black 40%, transparent 100%)",
        }}
      />

      <svg
        className="absolute -right-10 top-10 h-[480px] w-[480px] opacity-70 motion-reduce:animate-none sm:h-[560px] sm:w-[560px]"
        viewBox="0 0 400 400"
        fill="none"
      >
        <defs>
          <linearGradient id="trace" x1="0" y1="0" x2="400" y2="400" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#67e8ce" />
            <stop offset="1" stopColor="#9b8cfa" />
          </linearGradient>
        </defs>
        <motion.path
          d="M40 320 L40 200 L120 200 L120 80 L220 80 L220 160 L360 160"
          stroke="url(#trace)"
          strokeWidth="1.4"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 0.5 }}
          transition={{ duration: 2.2, ease: [0.16, 1, 0.3, 1], delay: 0.4 }}
        />
        <motion.path
          d="M60 60 L60 120 L160 120 L160 260 L300 260 L300 340"
          stroke="url(#trace)"
          strokeWidth="1.4"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 0.35 }}
          transition={{ duration: 2.4, ease: [0.16, 1, 0.3, 1], delay: 0.7 }}
        />
        {[
          [40, 320],
          [120, 200],
          [220, 80],
          [360, 160],
          [60, 60],
          [160, 260],
          [300, 340],
        ].map(([cx, cy], i) => (
          <circle key={i} cx={cx} cy={cy} r="3.5" fill="#67e8ce" className="animate-pulse-soft" />
        ))}
      </svg>
    </div>
  );
}
