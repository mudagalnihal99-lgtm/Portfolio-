import { Github, Linkedin, Instagram, Mail, ArrowUp } from "lucide-react";
import { profile, socialLinks } from "@/data/portfolio";

const socials = [
  { label: "Email", href: socialLinks.email, icon: Mail },
  { label: "GitHub", href: socialLinks.github, icon: Github },
  { label: "LinkedIn", href: socialLinks.linkedin, icon: Linkedin },
  { label: "Instagram", href: socialLinks.instagram, icon: Instagram },
];

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-line">
      <div className="container-content flex flex-col items-center gap-6 py-10 sm:flex-row sm:justify-between">
        <div className="text-center sm:text-left">
          <p className="font-display text-base font-semibold text-ash-100">{profile.name}</p>
          <p className="mt-1 text-sm text-ash-500">Building. Learning. Creating.</p>
        </div>

        <ul className="flex items-center gap-3">
          {socials.map(({ label, href, icon: Icon }) => (
            <li key={label}>
              <a
                href={href}
                target={label === "Email" ? undefined : "_blank"}
                rel={label === "Email" ? undefined : "noreferrer"}
                aria-label={label}
                className="flex h-9 w-9 items-center justify-center rounded-full border border-line text-ash-500 transition-colors duration-200 hover:border-signal-cyan/40 hover:text-ash-100"
              >
                <Icon size={16} />
              </a>
            </li>
          ))}
        </ul>

        <div className="flex items-center gap-4">
          <p className="text-xs text-ash-700">
            © {year} {profile.name}. All rights reserved.
          </p>
          <button
            type="button"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            aria-label="Back to top"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-line text-ash-500 transition-colors duration-200 hover:border-signal-cyan/40 hover:text-ash-100"
          >
            <ArrowUp size={16} />
          </button>
        </div>
      </div>
    </footer>
  );
}
