import { motion } from "framer-motion";
import { Github, ArrowUpRight } from "lucide-react";
import { projects, type Project } from "@/data/portfolio";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { cn } from "@/lib/utils";

const accentMap: Record<Project["accent"], string> = {
  cyan: "from-signal-cyan/25 to-transparent",
  violet: "from-signal-violet/25 to-transparent",
  copper: "from-signal-copper/25 to-transparent",
};

const accentTextMap: Record<Project["accent"], string> = {
  cyan: "text-signal-cyan",
  violet: "text-signal-violet",
  copper: "text-signal-copper",
};

export function Projects() {
  return (
    <section id="projects" className="container-content py-24 sm:py-32">
      <SectionHeading
        kicker="projects"
        title="Featured projects"
        description="A few things I've built to solve real problems, end to end."
      />

      <div className="grid gap-6 md:grid-cols-2">
        {projects.map((project, i) => (
          <motion.article
            key={project.name}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.55, delay: (i % 2) * 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="group relative overflow-hidden rounded-2xl border border-line bg-surface/50"
          >
            <div
              className={cn(
                "relative flex h-40 items-center justify-center overflow-hidden border-b border-line bg-gradient-to-br",
                accentMap[project.accent]
              )}
            >
              <span className="font-display text-2xl font-semibold tracking-tight text-ash-100/90">
                {project.name}
              </span>
              <div
                className="absolute inset-0 opacity-40 transition-transform duration-500 ease-out group-hover:scale-105"
                style={{
                  backgroundImage:
                    "linear-gradient(to right, rgba(255,255,255,0.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.06) 1px, transparent 1px)",
                  backgroundSize: "28px 28px",
                }}
              />
            </div>

            <div className="p-6">
              <h3 className="text-xl font-semibold text-ash-100">{project.name}</h3>
              <p className="mt-2.5 text-sm leading-relaxed text-ash-500">{project.description}</p>

              <ul className="mt-4 flex flex-wrap gap-2">
                {project.tech.map((tech) => (
                  <li
                    key={tech}
                    className={cn(
                      "rounded-md border border-line bg-ink/40 px-2.5 py-1 text-xs",
                      accentTextMap[project.accent]
                    )}
                  >
                    {tech}
                  </li>
                ))}
              </ul>

              <div className="mt-6 flex items-center gap-4">
                <a
                  href={project.github}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-sm text-ash-300 transition-colors duration-200 hover:text-ash-100"
                >
                  <Github size={16} />
                  Code
                </a>
                <a
                  href={project.demo}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-sm text-ash-300 transition-colors duration-200 hover:text-ash-100"
                >
                  Live Demo
                  <ArrowUpRight size={14} />
                </a>
              </div>
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  );
}
