import { useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import { Mail, Github, Linkedin, Instagram, Send, Check } from "lucide-react";
import { socialLinks } from "@/data/portfolio";
import { SectionHeading } from "@/components/ui/SectionHeading";

const socials = [
  { label: "Email", href: socialLinks.email, icon: Mail },
  { label: "GitHub", href: socialLinks.github, icon: Github },
  { label: "LinkedIn", href: socialLinks.linkedin, icon: Linkedin },
  { label: "Instagram", href: socialLinks.instagram, icon: Instagram },
];

export function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Portfolio contact from ${form.name || "a visitor"}`);
    const body = encodeURIComponent(
      `${form.message}\n\n— ${form.name || "Anonymous"} (${form.email || "no email provided"})`
    );
    window.location.href = `${socialLinks.email}?subject=${subject}&body=${body}`;
    setSent(true);
  };

  return (
    <section id="contact" className="container-content py-24 sm:py-32">
      <SectionHeading kicker="contact" title="Have an idea or want to collaborate?" />

      <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <p className="max-w-sm text-base leading-relaxed text-ash-500">
            Whether it's a project, an idea, or just a question about something I built — I'd like
            to hear from you.
          </p>

          <ul className="mt-8 space-y-3">
            {socials.map(({ label, href, icon: Icon }) => (
              <li key={label}>
                <a
                  href={href}
                  target={label === "Email" ? undefined : "_blank"}
                  rel={label === "Email" ? undefined : "noreferrer"}
                  className="group inline-flex items-center gap-3 text-sm text-ash-300 transition-colors duration-200 hover:text-ash-100"
                >
                  <span className="flex h-9 w-9 items-center justify-center rounded-full border border-line transition-colors duration-200 group-hover:border-signal-cyan/40">
                    <Icon size={16} />
                  </span>
                  {label}
                </a>
              </li>
            ))}
          </ul>
        </motion.div>

        <motion.form
          onSubmit={handleSubmit}
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="rounded-2xl border border-line bg-surface/40 p-6 sm:p-8"
        >
          <div className="grid gap-5 sm:grid-cols-2">
            <div className="sm:col-span-1">
              <label htmlFor="name" className="mb-1.5 block text-sm text-ash-500">
                Name
              </label>
              <input
                id="name"
                required
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                className="w-full rounded-lg border border-line bg-ink/60 px-3.5 py-2.5 text-sm text-ash-100 outline-none transition-colors duration-200 focus:border-signal-cyan/50"
                placeholder="Your name"
              />
            </div>
            <div className="sm:col-span-1">
              <label htmlFor="email" className="mb-1.5 block text-sm text-ash-500">
                Email
              </label>
              <input
                id="email"
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                className="w-full rounded-lg border border-line bg-ink/60 px-3.5 py-2.5 text-sm text-ash-100 outline-none transition-colors duration-200 focus:border-signal-cyan/50"
                placeholder="you@example.com"
              />
            </div>
            <div className="sm:col-span-2">
              <label htmlFor="message" className="mb-1.5 block text-sm text-ash-500">
                Message
              </label>
              <textarea
                id="message"
                required
                rows={4}
                value={form.message}
                onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                className="w-full resize-none rounded-lg border border-line bg-ink/60 px-3.5 py-2.5 text-sm text-ash-100 outline-none transition-colors duration-200 focus:border-signal-cyan/50"
                placeholder="What's on your mind?"
              />
            </div>
          </div>

          <button
            type="submit"
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-signal-gradient px-6 py-3 text-sm font-medium text-ink transition-transform duration-200 hover:scale-[1.02] active:scale-[0.98]"
          >
            {sent ? (
              <>
                <Check size={16} /> Message ready
              </>
            ) : (
              <>
                Send Message <Send size={15} />
              </>
            )}
          </button>
          {sent && (
            <p className="mt-3 text-xs text-ash-500">
              Your email client should have opened with this message pre-filled.
            </p>
          )}
        </motion.form>
      </div>
    </section>
  );
}
