import { motion } from "framer-motion";
import { Code2, Server, Database, Cpu, Wrench, Sparkles, type LucideIcon } from "lucide-react";
import { skillCategories } from "@/data/portfolio";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { GlowCard } from "@/components/ui/GlowCard";

const icons: Record<string, LucideIcon> = {
  Frontend: Code2,
  Backend: Server,
  Database: Database,
  Programming: Cpu,
  Tools: Wrench,
  AI: Sparkles,
};

export function Skills() {
  return (
    <section id="skills" className="container-content py-24 sm:py-32">
      <SectionHeading
        kicker="skills"
        title="What I work with"
        description="Tools and technologies I reach for when building something real."
      />

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {skillCategories.map((category, i) => {
          const Icon = icons[category.title] ?? Code2;
          return (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.08, ease: [0.16, 1, 0.3, 1] }}
            >
              <GlowCard className="h-full">
                <div className="flex items-start justify-between">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-line bg-ink/60 text-signal-cyan">
                    <Icon size={18} />
                  </div>
                </div>

                <h3 className="mt-5 text-lg font-semibold text-ash-100">{category.title}</h3>
                <p className="mt-1.5 text-sm text-ash-500">{category.description}</p>

                <ul className="mt-5 flex flex-wrap gap-2">
                  {category.skills.map((skill) => (
                    <li
                      key={skill}
                      className="rounded-md border border-line bg-ink/40 px-2.5 py-1 text-xs text-ash-300 transition-colors duration-200 group-hover:border-signal-violet/25"
                    >
                      {skill}
                    </li>
                  ))}
                </ul>
              </GlowCard>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
