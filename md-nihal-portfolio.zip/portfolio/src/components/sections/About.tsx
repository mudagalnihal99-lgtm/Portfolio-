import { motion } from "framer-motion";
import { profile, stats } from "@/data/portfolio";
import { SectionHeading } from "@/components/ui/SectionHeading";

export function About() {
  return (
    <section id="about" className="container-content py-24 sm:py-32">
      <SectionHeading kicker="about" title="A bit about me" />

      <div className="grid gap-12 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        >
          <p className="text-lg leading-relaxed text-ash-300">{profile.aboutParagraph}</p>

          <ul className="mt-8 flex flex-wrap gap-2">
            {profile.interests.map((interest) => (
              <li
                key={interest}
                className="rounded-full border border-line bg-surface/50 px-4 py-1.5 text-sm text-ash-300"
              >
                {interest}
              </li>
            ))}
          </ul>
        </motion.div>

        <div className="grid grid-cols-2 gap-4">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
              className="rounded-2xl border border-line bg-surface/40 p-6"
            >
              <p className="font-display text-3xl font-semibold text-gradient">{stat.value}</p>
              <p className="mt-2 text-sm text-ash-500">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
