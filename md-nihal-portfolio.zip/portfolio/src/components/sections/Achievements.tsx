import { motion } from "framer-motion";
import { achievements } from "@/data/portfolio";
import { SectionHeading } from "@/components/ui/SectionHeading";

export function Achievements() {
  return (
    <section id="achievements" className="container-content py-24 sm:py-32">
      <SectionHeading
        kicker="highlights"
        title="Achievements"
        description="Milestones so far — updated as new ones happen."
      />

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {achievements.map((item, i) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="rounded-2xl border border-line bg-surface/40 p-6"
          >
            <p className="font-display text-4xl font-semibold text-gradient">{item.value}</p>
            <p className="mt-3 text-sm font-medium text-ash-100">{item.label}</p>
            <p className="mt-1.5 text-xs leading-relaxed text-ash-500">{item.detail}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
