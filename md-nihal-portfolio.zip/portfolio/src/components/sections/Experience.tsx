import { motion } from "framer-motion";
import { timeline } from "@/data/portfolio";
import { SectionHeading } from "@/components/ui/SectionHeading";

export function Experience() {
  return (
    <section id="experience" className="container-content py-24 sm:py-32">
      <SectionHeading kicker="journey" title="Experience & journey" />

      <div className="relative max-w-2xl">
        <div className="absolute left-[7px] top-2 bottom-2 w-px bg-line sm:left-[9px]" />

        <ol className="space-y-10">
          {timeline.map((entry, i) => (
            <motion.li
              key={entry.title}
              initial={{ opacity: 0, x: -14 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.5, delay: i * 0.06, ease: [0.16, 1, 0.3, 1] }}
              className="relative pl-8 sm:pl-10"
            >
              <span className="absolute left-0 top-1.5 h-3.5 w-3.5 rounded-full border-2 border-signal-cyan bg-ink sm:h-[18px] sm:w-[18px]" />
              <p className="font-mono text-xs text-signal-cyan">{entry.year}</p>
              <h3 className="mt-1.5 text-lg font-semibold text-ash-100">{entry.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-ash-500">{entry.description}</p>
            </motion.li>
          ))}
        </ol>
      </div>
    </section>
  );
}
