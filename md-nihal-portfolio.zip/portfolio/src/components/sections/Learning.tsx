import { motion } from "framer-motion";
import { currentlyLearning } from "@/data/portfolio";
import { SectionHeading } from "@/components/ui/SectionHeading";

export function Learning() {
  return (
    <section id="learning" className="container-content py-24 sm:py-32">
      <SectionHeading kicker="in progress" title="Currently learning" />

      <div className="flex flex-wrap gap-4">
        {currentlyLearning.map((topic, i) => (
          <motion.div
            key={topic.title}
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.45, delay: i * 0.06, ease: [0.16, 1, 0.3, 1] }}
            className="w-full rounded-xl border border-line bg-surface/40 px-5 py-4 sm:w-[calc(50%-0.5rem)] lg:w-[calc(33.333%-0.7rem)]"
          >
            <div className="flex items-center gap-2.5">
              <span className="h-1.5 w-1.5 rounded-full bg-signal-cyan animate-pulse-soft" />
              <h3 className="text-sm font-medium text-ash-100">{topic.title}</h3>
            </div>
            <p className="mt-2 text-xs leading-relaxed text-ash-500">{topic.description}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
