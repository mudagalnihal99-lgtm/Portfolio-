// ─────────────────────────────────────────────────────────────────────────
// Centralized portfolio content.
// Edit everything about MD Nihal's site from this single file.
// ─────────────────────────────────────────────────────────────────────────

export const profile = {
  name: "MD Nihal",
  role: "Electronics & Computer Engineering Student",
  location: "India",
  tagline: "Building, Learning & Creating with Technology",
  heroDescription:
    "I build modern web experiences, experiment with AI, and turn ideas into practical projects.",
  aboutParagraph:
    "I'm an engineering student who splits my time between coursework and shipping things that actually run. I'm drawn to software development, AI, and full-stack engineering — the parts of electronics & computer engineering where an idea turns into something you can click on. Most of what I know I've picked up by building, breaking, and rebuilding real projects.",
  interests: [
    "Software Development",
    "AI",
    "Full Stack Development",
    "Problem Solving",
    "Building real-world products",
  ],
};

export const navLinks = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Projects", href: "#projects" },
  { label: "Experience", href: "#experience" },
  { label: "Contact", href: "#contact" },
];

export const socialLinks = {
  email: "mailto:your.email@example.com",
  github: "https://github.com/your-username",
  linkedin: "https://linkedin.com/in/your-username",
  instagram: "https://instagram.com/your-username",
};

export const stats = [
  { label: "Engineering Student", value: "3rd Yr" },
  { label: "Projects Built", value: "12+" },
  { label: "Technologies Learned", value: "20+" },
  { label: "Hackathons / Events", value: "4" },
];

export type SkillCategory = {
  title: string;
  description: string;
  skills: string[];
};

export const skillCategories: SkillCategory[] = [
  {
    title: "Frontend",
    description: "Interfaces that feel fast and deliberate.",
    skills: ["HTML", "CSS", "JavaScript", "React", "TypeScript", "Tailwind CSS"],
  },
  {
    title: "Backend",
    description: "APIs and services that hold up under real use.",
    skills: ["Node.js", "Express", "REST APIs"],
  },
  {
    title: "Database",
    description: "Storing and modeling data with intent.",
    skills: ["Supabase", "MongoDB"],
  },
  {
    title: "Programming",
    description: "The languages I think in.",
    skills: ["C", "C++", "JavaScript", "TypeScript"],
  },
  {
    title: "Tools",
    description: "My day-to-day workflow.",
    skills: ["Git", "GitHub", "Vercel", "VS Code"],
  },
  {
    title: "AI",
    description: "Building with and around AI models.",
    skills: ["AI APIs", "Prompt Engineering", "AI-assisted development"],
  },
];

export type Project = {
  name: string;
  description: string;
  tech: string[];
  github: string;
  demo: string;
  accent: "cyan" | "violet" | "copper";
};

export const projects: Project[] = [
  {
    name: "PrepPilot.ai",
    description:
      "An AI-powered student preparation platform designed to help students practice mock tests and prepare more effectively.",
    tech: ["React", "TypeScript", "AI APIs", "Supabase"],
    github: "https://github.com/your-username/preppilot-ai",
    demo: "https://preppilot.example.com",
    accent: "cyan",
  },
  {
    name: "EcoGuard+",
    description:
      "An AI-based environmental monitoring and smart waste-management concept using sensors and real-time monitoring.",
    tech: ["React", "Node.js", "IoT Sensors", "MongoDB"],
    github: "https://github.com/your-username/ecoguard-plus",
    demo: "https://ecoguard.example.com",
    accent: "violet",
  },
  {
    name: "Project Name Three",
    description:
      "Short description of this project — what it does, who it's for, and the problem it solves. Replace with real details.",
    tech: ["React", "Express", "MongoDB"],
    github: "https://github.com/your-username/project-three",
    demo: "https://project-three.example.com",
    accent: "copper",
  },
  {
    name: "Project Name Four",
    description:
      "Short description of this project — what it does, who it's for, and the problem it solves. Replace with real details.",
    tech: ["Next.js", "TypeScript", "Tailwind CSS"],
    github: "https://github.com/your-username/project-four",
    demo: "https://project-four.example.com",
    accent: "cyan",
  },
];

export type TimelineItem = {
  year: string;
  title: string;
  description: string;
};

export const timeline: TimelineItem[] = [
  {
    year: "2023",
    title: "Started Electronics & Computer Engineering",
    description:
      "Began my degree, splitting focus between core electronics coursework and self-taught programming.",
  },
  {
    year: "2023 — 2024",
    title: "Learning Full Stack Development",
    description:
      "Picked up HTML, CSS, JavaScript, then moved into React, TypeScript, and backend fundamentals with Node.js.",
  },
  {
    year: "2024",
    title: "First Hackathon",
    description:
      "Built a working prototype under time pressure with a team for the first time — replace with your actual hackathon name and outcome.",
  },
  {
    year: "2024 — Present",
    title: "Building Real Projects",
    description:
      "Started shipping full projects end-to-end, including PrepPilot.ai and EcoGuard+, to apply what I was learning.",
  },
  {
    year: "Present",
    title: "Sharing What I Learn",
    description:
      "Documenting my process and projects — replace with details on any content, writing, or community involvement.",
  },
];

export type Achievement = {
  label: string;
  value: string;
  detail: string;
};

export const achievements: Achievement[] = [
  { label: "Hackathons", value: "4", detail: "Participated in, across teams and solo builds" },
  { label: "Projects", value: "12+", detail: "Shipped end-to-end, from idea to deploy" },
  { label: "Certifications", value: "3", detail: "In web development and core CS fundamentals" },
  { label: "Events", value: "6+", detail: "Tech talks, workshops, and student meetups attended" },
];

export const currentlyLearning = [
  {
    title: "Full Stack Development",
    description: "Deepening backend architecture and API design patterns.",
  },
  {
    title: "Data Structures & Algorithms",
    description: "Building a stronger foundation for problem-solving and interviews.",
  },
  {
    title: "AI Development",
    description: "Working with AI APIs and exploring how to build with them well.",
  },
  {
    title: "UI/UX",
    description: "Learning to design interfaces before I build them.",
  },
  {
    title: "System Design",
    description: "Understanding how real systems scale beyond a single project.",
  },
];
