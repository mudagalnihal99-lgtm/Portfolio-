# MD Nihal — Portfolio

A dark, premium developer portfolio built with React, TypeScript, Vite, Tailwind CSS, and Framer Motion.

## Getting started

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually `http://localhost:5173`).

To build for production:

```bash
npm run build
npm run preview
```

## Editing your content

Almost everything on the site — your name, bio, stats, skills, projects, timeline,
achievements, learning list, and social links — lives in one file:

```
src/data/portfolio.ts
```

Open it and edit the plain objects/arrays. No component code needs to change for
normal content updates.

Things to personalize before deploying:
- `socialLinks` — replace with your real email, GitHub, LinkedIn, Instagram URLs.
- `projects` — replace the two placeholder projects and update GitHub/demo links
  for PrepPilot.ai and EcoGuard+.
- `stats`, `achievements`, `timeline` — replace placeholder numbers with real ones.
- `index.html` — update `og:url` and add a real `public/og-cover.png` (1200×630)
  if you want a rich social share preview.
- `public/favicon.svg` — swap for your own mark if you'd like.

## Project structure

```
src/
  components/
    layout/     Navbar, Footer, CircuitField (background)
    sections/   Hero, About, Skills, Projects, Experience, Achievements, Learning, Contact
    ui/         SectionHeading, GlowCard (shared building blocks)
  data/
    portfolio.ts   ← all editable content
  hooks/
    useActiveSection.ts   scroll + active-nav-link tracking
  lib/
    utils.ts
  App.tsx
  main.tsx
  index.css
```

## Notes

- Motion respects `prefers-reduced-motion`.
- The contact form has no backend — submitting it opens the visitor's email client
  with the message pre-filled via a `mailto:` link (no API keys or credentials
  required). Swap in a real form service (Formspree, Resend, etc.) if you want
  server-side delivery instead.
- Tailwind design tokens (colors, fonts, gradient) live in `tailwind.config.ts`.
