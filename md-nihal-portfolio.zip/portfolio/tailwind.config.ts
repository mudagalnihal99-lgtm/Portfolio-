import type { Config } from "tailwindcss";

export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#0b0b0e",
          soft: "#111114",
        },
        surface: {
          DEFAULT: "#141417",
          hover: "#1b1b20",
        },
        line: "#26262c",
        ash: {
          100: "#f2f2f4",
          300: "#c7c7cf",
          500: "#8e8e96",
          700: "#5c5c63",
        },
        signal: {
          cyan: "#67e8ce",
          violet: "#9b8cfa",
          copper: "#e3a76f",
        },
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
      backgroundImage: {
        "signal-gradient": "linear-gradient(115deg, #67e8ce 0%, #9b8cfa 100%)",
        "signal-gradient-soft":
          "linear-gradient(115deg, rgba(103,232,206,0.14) 0%, rgba(155,140,250,0.14) 100%)",
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(103,232,206,0.15), 0 8px 30px -8px rgba(103,232,206,0.25)",
        card: "0 20px 60px -25px rgba(0,0,0,0.6)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(14px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "pulse-soft": {
          "0%, 100%": { opacity: "0.35" },
          "50%": { opacity: "0.75" },
        },
        drift: {
          "0%": { transform: "translate3d(0,0,0)" },
          "50%": { transform: "translate3d(0,-14px,0)" },
          "100%": { transform: "translate3d(0,0,0)" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.7s cubic-bezier(0.16,1,0.3,1) both",
        "pulse-soft": "pulse-soft 4s ease-in-out infinite",
        drift: "drift 7s ease-in-out infinite",
      },
      maxWidth: {
        content: "72rem",
      },
    },
  },
  plugins: [],
} satisfies Config;
